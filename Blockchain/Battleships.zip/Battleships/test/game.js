var Game = artifacts.require('BattleShip');
const truffleAssert = require('truffle-assertions');

let accounts, owner, player1, player2, minInitBalance, instance;
contract('Game', () => {

    beforeEach(async () => {
        accounts = web3.eth.getAccounts();
        owner = accounts[0];
        player1 = accounts[1];
        player2 = accounts[2];
        minInitBalance = web3.utils.toWei('1', 'ether');
        instance = await Game.deployed();
    });

    describe('constructor', () => {
        it('assigns the owner correctly', async () => {
                const _balance = await web3.eth.getBalance(instance.address);
                assert(_balance >= minInitBalance, 'contract balance >= minimum required balance');

        });
    });

    describe('init_game', () => {

        describe('success', () => {
            it('initialises bot game correctly', async () => {
                await instance.initBot();
                // const botGame = await instance.botGames.call(0);
                // const botGame = await instance.availableGames.call(0);
                // const {player1,  player2, gamestate, count } = botGame;
                const gameCount = await instance.totalGames;
                // assert.equal(player, player1, 'initialises player correctly');
                // assert.equal(val, _val, 'initialises value correctly');
                assert.equal(gameCount, 1, 'game counter incremented successfully');
                // assert.equal(wins, 10, 'initialises wins correctly');
            });
        });

        // describe('failure', async () => {
        //     it('value sent to initialise is 0', async () => {
        //         await truffleAssert.reverts(instance.initBot({ from: owner }), "bet must be > 0"); // same as require
        //     });
        // });
    });

    // describe('playBot', () => {
    //     beforeEach(async () => {
    //         const _val = 11;
    //         await instance.initBot({from: player1, value: _val});
    //     });
    //     describe('success', () => {
    //         it('botGame is played successfully', async () => {
    //             try {
    //                 const _choice = 1;
    //                 await instance.playBot(0,_choice,{from: player1});
    //                 const botGame = await instance.botGames.call(0);
    //                 const {player, val, count, wins } = botGame;
    //                 assert.equal(count, 1, 'count of game incremented successfully');
    //             } catch (err) {
    //                 assert.isUndefined(err.message);
    //             }
    //         });
    //     });
    // });

    // describe('init', () => {
    //     describe('success', () => {
    //         it('initialises two-player game correctly', async () => {
    //             try {
    //                 const _val = 11;
    //                 await instance.init({from: player1, value: _val});
    //                 // console.log(game_id)
    //                 const val = await instance.openGames.call(0);
    //                 console.log(val);
    //                 // const {p1, val } = two_game;
    //                 // assert.equal(p1, player1, 'initialises player correctly');
    //                 assert.equal(val, _val, 'initialises value correctly');
    //                 // assert.equal(count, 0, 'initialises count correctly');
    //                 // assert.equal(wins, 10, 'initialises wins correctly');
    //             } catch (err) {
    //                 assert.isUndefined(err.message);
    //             }
    //         });
    //     });

    //     describe('failure', async () => {
    //         it('value sent to initialise is 0', async () => {
    //             await truffleAssert.reverts(instance.initBot({ from: owner }), "bet must be > 0"); // same as require
    //         });
    //     });
    // });

    // describe('start', () => {
    //     beforeEach(async () => {
    //         const _val = 11;
    //         await instance.init({from: player1, value: _val});
    //     });
    //     describe('success', () => {
    //         it('two-player game is started successfully', async () => {
    //             try {
    //                 const _val2 = 11;
    //                 await instance.start(0,{from: player2, value: _val2});
    //                 const two_game = await instance.runningGames.call(0);
    //                 const {p1, p2, val, count, wins } = two_game;
    //                 assert.equal(p1, player1, 'initialises player correctly');
    //                 assert.equal(p2, player2, 'initialises player correctly');
    //                 assert.equal(val, _val2, 'value is not changed');
    //                 assert.equal(count, 0, 'initialises count correctly');
    //                 assert.equal(wins, 10, 'initialises wins correctly');
    //             } catch (err) {
    //                 assert.isUndefined(err.message);
    //             }
    //         });
    //     });
    // });
    // describe('playHidden', () => {
    //     beforeEach(async () => {
    //         const _val = 11;
    //         await instance.init({from: player1, value: _val});
    //         await instance.start(1,{from: player2, value: _val});
    //     });
    //     describe('success', () => {
    //         it('two-player game is played by some player', async () => {
    //             try {
    //                 const _choice = 1;
    //                 const _rand_num = 1001;
    //                 const _hashval = web3.utils.soliditySha3(_choice, _rand_num);
    //                 await instance.playHidden(1,_hashval,{from: player1});
    //                 const two_game = await instance.runningGames(1);
    //                 const {hiddenChoice1} = two_game;
    //                 assert.equal(hiddenChoice1, _hashval, 'Hashval stored correctly');
    //             } catch (err) {
    //                 assert.isUndefined(err.message);
    //             }
    //         });
    //     });
    // });

    // describe('reveal', () => {
    //     beforeEach(async () => {
    //         const choice1 = 1;
    //         const _rand_num1 = 1010;
    //         const choice2 = 2;
    //         const _rand_num2 = 1001;
    //         const _hashval1 = web3.utils.soliditySha3(choice1, _rand_num1);
    //         const _hashval2 = web3.utils.soliditySha3(choice2, _rand_num2);
    //         await instance.init({from: player1, value: 11});
    //         await instance.start(2, {from: player2, value: 11});
    //         await instance.playHidden(2, _hashval1, {from: player1});
    //         await instance.playHidden(2, _hashval2, {from: player2});
    //     });
    //     it('reveals correctly', async () => {
    //         try {
    //             const choice1 = 1;
    //             const _rand_num1 = 1010;
    //             const choice2 = 2;
    //             const _rand_num2 = 1001;
    //             await instance.reveal(2, choice1, _rand_num1, {from: player1}); 
    //             await instance.reveal(2, choice2, _rand_num2, {from: player2});
    //             const two_game = await instance.runningGames(2);
    //             const {count, wins} = two_game;
    //             assert.equal(count, 1, 'count is correct');
    //             assert.equal(wins, 9, 'wins is correct');
    //         } catch (err) {
    //             assert.isUndefined(err.message);
    //         }
    //     });
    // });
    // describe('totalGames', () => {
    //     it('increments totalGames count correctly', async () => {
    //         try {
    //             const val = await instance.totalGames.call();
    //             assert.equal(val.toNumber(), 4, 'increments count correctly');
    //         } catch (err) {
    //             assert.isUndefined(err.message);
    //         }
    //     });
    // });
});