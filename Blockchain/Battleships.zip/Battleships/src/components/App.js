import React, { Component } from 'react';
import Web3 from 'web3';
import './App.css';
import HighLow from '../abis/HighLow.json';
import Navbar from './Navbar.js';
import Main from './Main.js';

class App extends Component {

    async componentWillMount() {
        await this.loadWeb3()
        await this.loadBlockchainData()
    }

    async componentDidMount() {
        this.regular = setInterval(
            () => this.tick(),
            5000
        );
    }

    async tick() {
        // Function to update necessary State Variables
        //
        if (typeof this.state.highlow !== 'undefined') {
            const web3 = window.web3

            console.log('tick')
            let stage = await this.state.highlow.methods.stage.call()
            console.log('stage', stage)
            this.setState({ stage })

            let balance = await web3.eth.getBalance(this.state.account) 
            balance = await web3.utils.fromWei(balance.toString(), 'Ether')
            console.log('balance', balance)
            this.setState({ balance })
        }
    }

    // Only needed for web3 sync, no contribution to program logic
    async loadWeb3() {
        if (window.ethereum) {
            window.web3 = new Web3(window.ethereum)
            await window.ethereum.enable()
        }
        else if (window.web3) {
            window.web3 = new Web3(window.web3.currentProvider)
        }
        else {
            window.alert('Non-Ethereum browser detected. You should consider trying Metamask.')
        }
    }

    async deploy(accounts) {
        const web3 = window.web3

        const netID = await web3.eth.net.getId()
        const netData = HighLow.networks[netID]

        if (netData) {
            const contract= web3.eth.Contract(HighLow.abi, netData.address)
            contract.transactionConfirmationBlocks = 1;

            const response = await contract.deploy({
                data: HighLow.bytecode,
                arguments: [accounts[0]]
            }).send({
                from: accounts[0],
                gas: 6000000,
                gasPrice: '200000000'
            })

            console.log('Contract deployed to:', response.address);
            console.log('Contract deployed to:', response.options.address);
        
            return response;
        }
        else {
            window.alert('HighLow has not been deployed to this network')
        }

    }

    // Load data from the blockchain into the app to use
    async loadBlockchainData() {
        const web3 = window.web3

        // Get Account
        const accounts = await web3.eth.getAccounts()
        console.log('accounts', accounts)
        this.setState({ account:accounts[0] })

        // Get balance
        let balance = await web3.eth.getBalance(accounts[0]) 
        balance = await web3.utils.fromWei(balance.toString(), 'Ether')
        console.log(balance)
        this.setState({ balance })
        
        // Instantiate contract and deploy
        const highlow = await this.deploy(accounts)
        console.log(highlow)
        this.setState({ highlow })

        // Get current visible card
        let placedCard = await highlow.methods.placedCard.call()
        console.log(placedCard)
        this.setState({ placedCard })

        // Current visible card name
        let placedCardNamed = await highlow.methods.getPlacedCard().call()
        console.log(placedCardNamed)
        this.setState({ placedCardNamed })

        // Get current stage  
        let stage = await highlow.methods.stage.call()
        console.log('stage', stage)
        this.setState({ stage })

        this.setState({ loading:false })

        console.log(this.state)
    }

    async placeBet (hash, amount) {
        const web3 = window.web3
        this.setState({ loading:true }) 
        
        let val1 = web3.utils.toWei(amount.toString(), "ether")
        console.log(val1)

        this.state.highlow.methods.bet(hash).send({from: this.state.account, value: val1, gas: 100000}); 
        console.log('Actually placed bet');

        this.setState({ loading:false })
        console.log(this.state)
    }

    async revealBet(prediction, rnd) {
        const web3 = window.web3
        this.setState({ loading:true })

        this.state.highlow.methods.reveal(prediction, rnd).send({
            from: this.state.account, 
            gas: 100000
        });
        console.log('Actually revealed bet');
        
        let balance = await web3.eth.getBalance(this.state.account)
        console.log('newbalance', this.state.balance)
        this.setState({ balance })

        this.setState({ loading: false })
        console.log(this.state)
    }

    constructor(props) {
        super(props)
        this.state = {
            loading: true,
        }

        this.tick= this.tick.bind(this)
        this.deploy = this.deploy.bind(this)
        this.placeBet = this.placeBet.bind(this)
        this.revealBet = this.revealBet.bind(this)
        this.loadBlockchainData = this.loadBlockchainData.bind(this)
    }
    
  render() {
    return (
        <div>
            <Navbar account={ this.state.account } />
            <div className="row">
                <main role="main" className="col-lg-12 d-flex text-center mt-5">
                    {   this.state.loading
                        ? <div id="loader" className="text-center"><p className="text-center">Loading...</p></div>
                        : <Main 
                            account = { this.state.account }
                            placedCard = {this.state.placedCard}
                            placedCardNamed = { this.state.placedCardNamed }
                            balance = { this.state.balance }
                            placeBet = { this.placeBet }
                            revealBet = { this.revealBet }
                        />
                        
                    }
                </main>
            </div>
      </div>
    );
  }
}

export default App;
