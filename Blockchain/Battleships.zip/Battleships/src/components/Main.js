import React, { Component } from 'react';
import Web3 from 'web3';

class Main extends Component {

    handleHigh(event) {
        event.preventDefault();
        // let amount = window.web3.utils.toWei(this.betAmount.value.toString(), 'Ether')
        // let amount = 20000000;
        let amount = this.betAmount.value
        let prediction = true
        this.setState({ prediction })

        let rnd = window.web3.utils.randomHex(32);
        let hx = window.web3.utils.soliditySha3(prediction, rnd);
        let hash = window.web3.utils.hexToBytes(hx);
        this.setState({ rnd })

        this.props.placeBet(hash, amount)
        console.log('Main placed a bet:',prediction, hash, amount)
    }

    handleLow(event) {
        event.preventDefault();
        // let amount = window.web3.utils.toWei(this.betAmount.value.toString(), 'Ether')
        //let amount = 20000000;
        let amount = this.betAmount.value
        let prediction = false
        this.setState({ prediction })

        let rnd = window.web3.utils.randomHex(32);
        let hx = window.web3.utils.soliditySha3(prediction, rnd);
        let hash = window.web3.utils.hexToBytes(hx);
        this.setState({ rnd })

        this.props.placeBet(hash, amount)
        console.log('Main placed a bet:',prediction, hash, amount)
    }

    handleReveal(event) {
        event.preventDefault();

        let prediction = this.state.prediction
        let rnd = this.state.rnd

        this.props.revealBet(prediction, rnd)
        console.log('revealing bet from Main')
    }

  render() {
    return (
        
        <div className="content mr-auto ml-auto mt-auto mb-auto">
            <h1>For Account: { this.props.account } </h1>
            <h3>Revealed card: { this.props.placedCardNamed }</h3>
            <h3> Account Balance = { this.props.balance } Ether</h3>

            <form onSubmit={this.handleHigh.bind(this)}>
                <div className="form-group mr-sm-2">
                    <input 
                        id="betAmount"
                        type="text"
                        ref={(input) => { this.betAmount = input }}
                        className="form-control"
                        placeholder="Bet Amount"
                    required />
                </div>
                <button type="submit">High</button>
                <button onClick={this.handleLow.bind(this)}>Low</button>
                <button onClick={this.handleReveal.bind(this)}>Reveal</button>
            </form>

        </div>
    );
  }
}

export default Main;
