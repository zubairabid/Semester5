//var HighLow = artifacts.require("./HighLow.sol");
 
// var val = web3.utils.toWei("0.1", "ether");

//function sleep(ms) {
//  return new Promise(resolve => setTimeout(resolve, ms));
//}

//module.exports = async function(deployer, network, accounts) {
//  await deployer.deploy(HighLow, accounts[8], { from: accounts[8], value: val });
    // var highLowInstance = await HighLow.deployed();
    // highLowInstance.initializeRound();
//};
//

const BattleShip = artifacts.require('BattleShip');
const val = web3.utils.toWei('1', 'ether');

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

module.exports = async function(deployer, network, accounts) {
    await deployer.deploy(BattleShip, {value: val});
}
