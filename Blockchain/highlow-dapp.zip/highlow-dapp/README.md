# Assignment 3

**Team:** Ayush Deva (201501098), Zubair Abid (20171076)

React-based frontend for High-Low game made in assignment 1 of blockchain, for assignment 3 of blockchain.

## Environment Setup

This requires `node`, `ganache`, `truffle`, `Metamask`.

### Local Blockchain, Smart Contract
Start by running ganache - it usually comes as an AppImage, so do that.

```bash
(( git clone ))
npm install
truffle compile && truffle migrate --reset
npm run start
```

### Web Interaction

- Copy the private key from one of the provided Ganache accounts, and import it into Metamask.
- Setup a custom RPC to the Ganache network, it should be on localhost:7545 by default
- Authorize the application.


## On avoiding 10 hours of debugging hell

Things do not always behave intuitively. Welcome to JavaScript. Important points:

- If you're restarting Ganache, restart your browser that has Metamask running
- 
