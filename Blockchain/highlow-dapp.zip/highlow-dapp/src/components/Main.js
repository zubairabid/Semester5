import React, { Component } from 'react';
import Web3 from 'web3';

class Main extends Component {

    constructor(props) {
        super(props)
        this.state = {
            button: false,
        }
        this.handleHigh = this.handleHigh.bind(this)
        this.handleLow = this.handleLow.bind(this)
        this.handleReveal = this.handleReveal.bind(this)
    }

    handleHigh(event) {
        event.preventDefault();
        // let amount = window.web3.utils.toWei(this.betAmount.value.toString(), 'Ether')
        // let amount = 20000000;
        let amount = this.betAmount.value
        let prediction = true
        this.setState({ prediction })

        let rnd = window.web3.utils.randomHex(32);
        let hx = window.web3.utils.soliditySha3(prediction, rnd);
        let hash = window.web3.utils.hexToBytes(hx);
        this.setState({ rnd })

        this.props.placeBet(hash, amount)
        console.log('Main placed a bet:',prediction, hash, amount)
        this.setState({ button: true })
    }

    handleLow(event) {
        event.preventDefault();
        // let amount = window.web3.utils.toWei(this.betAmount.value.toString(), 'Ether')
        //let amount = 20000000;
        let amount = this.betAmount.value
        let prediction = false
        this.setState({ prediction })

        let rnd = window.web3.utils.randomHex(32);
        let hx = window.web3.utils.soliditySha3(prediction, rnd);
        let hash = window.web3.utils.hexToBytes(hx);
        this.setState({ rnd })

        this.props.placeBet(hash, amount)
        console.log('Main placed a bet:',prediction, hash, amount)
        this.setState({ button: true })
    }

    handleReveal(event) {
        event.preventDefault();
        console.log(this.state)

        let prediction = this.state.prediction
        let rnd = this.state.rnd

        this.props.revealBet(prediction, rnd)
        console.log('revealing bet from Main')
    }

  render() {
    return (
        
        <div className="content mr-auto ml-auto mt-auto mb-auto">
            <p><strong>Account Balance</strong> = { this.props.balance } Ether</p>
            <div className="row">
                <div className="col-md-4">
                    
                    <h3>Revealed card: { this.props.placedCardNamed }</h3>

                </div>
                <div className="col-md-4">

                    <form onSubmit={this.handleHigh}>
                        <div className="form-group mr-sm-2">
                            <input 
                                id="betAmount"
                                type="text"
                                ref={(input) => { this.betAmount = input }}
                                className="form-control"
                                placeholder="Bet Amount"
                            required />
                        </div>
                        {
                            this.state.button
                            ?   <button type="submit" className="btn btn-light"sdisabled>High</button>
                            :   <button type="submit" className="btn btn-light">High</button>
                        }
                        {
                            this.state.button
                            ?   <button onClick={this.handleLow} className="btn btn-dark" disabled>Low</button>
                            :   <button onClick={this.handleLow} className="btn btn-dark">Low</button>
                        }
                        {
                            this.state.button
                            ?   <button onClick={this.handleReveal} className="btn btn-secondary">Reveal</button>
                            :   <button onClick={this.handleReveal} className="btn btn-secondary" disabled>Reveal</button>
                        }
                    </form>
            
                </div>
                <div className="col-md-4"></div>
            </div>

        </div>
    );
  }
}

export default Main;
